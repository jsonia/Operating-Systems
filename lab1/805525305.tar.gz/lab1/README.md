# Pipe Up

This project contains the low level code performed by the pipe (|) operator in shells

## Building

`make` builds the code and creates a pipe executable

## Running

`./pipe sort file.txt uniq` this will sort the given file and print the unique files only

## Cleaning up

`make clean` removes all binary file
